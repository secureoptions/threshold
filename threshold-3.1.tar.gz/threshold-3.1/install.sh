#! /bin/bash

# Installation script must be run with superuser
if [ "$(id -u)" -ne 0 ]
then 
	echo ""
	echo "Permission denied (run with 'sudo'). Installation exiting..."
	echo ""
    exit 1
fi

# Check if python 2.7 is installed
python --version > /dev/null 2>1

result=$?

if [ $result -ne 0 ]
then
    echo ""
    echo 'You must have Python 2.7 installed before running this script'
    echo ""
    exit 1
fi


mv threshold.py /usr/bin/threshold
mkdir -p /etc/threshold
mv threshold.1.man /usr/share/man/man1/threshold.1
gzip /usr/share/man/man1/threshold.1


echo '...Installation Complete!'
echo 'You can now safely remove this directory and this installation script'

